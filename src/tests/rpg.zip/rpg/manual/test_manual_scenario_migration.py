from __future__ import annotations

from tests.rpg.manual.runner import build_service_scenarios
from tests.rpg.manual.scenarios.expected_campaign_director_m22_m24_names import (
    EXPECTED_CAMPAIGN_DIRECTOR_M22_M24_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_campaign_journal_m31_m33_names import (
    EXPECTED_CAMPAIGN_JOURNAL_M31_M33_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_companion_m28_m30_names import (
    EXPECTED_COMPANION_M28_M30_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_dialogue_m16_m18_names import (
    EXPECTED_DIALOGUE_M16_M18_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_escalation_m7_m9_names import (
    EXPECTED_ESCALATION_M7_M9_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_legacy_names import (
    EXPECTED_LEGACY_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_memory_l7_l9_names import (
    EXPECTED_MEMORY_L7_L9_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_quest_puzzle_l13_l15_names import (
    EXPECTED_QUEST_PUZZLE_L13_L15_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_social_l10_l12_names import (
    EXPECTED_SOCIAL_L10_L12_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_story_arc_milestones_m46_m48_names import (
    EXPECTED_STORY_ARC_MILESTONES_M46_M48_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_story_authoring_approval_m37_m39_names import (
    EXPECTED_STORY_AUTHORING_APPROVAL_M37_M39_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_story_event_m4_m6_names import (
    EXPECTED_STORY_EVENT_M4_M6_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_story_event_queue_m25_m27_names import (
    EXPECTED_STORY_EVENT_QUEUE_M25_M27_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_story_m1_m3_names import (
    EXPECTED_STORY_M1_M3_SCENARIO_NAMES,
)
from tests.rpg.manual.scenarios.expected_story_pack_m13_m15_names import (
    EXPECTED_STORY_PACK_M13_M15_SCENARIO_NAMES,
)


def test_manual_scenario_migration_audit():
    """Audit migration by comparing expected legacy names vs new modular registry.

    This test ensures we don't silently drop or add scenarios during refactoring.
    It compares against the current modular registry scenario count.
    """

    # Load expected legacy names (exact 145 from old monolith)
    all_old_names = EXPECTED_LEGACY_SCENARIO_NAMES
    print(f"Expected legacy scenario count: {len(all_old_names)}")

    # Load new scenarios (modular)
    new_scenarios = build_service_scenarios()
    new_names = set(new_scenarios.keys())

    # All scenarios should be present (updated count after campaign journal M31-M33 integration)
    assert len(new_names) == 327, f"Expected 327 scenarios, found {len(new_names)}"

    # Check that Bundle A scenarios have been successfully ported
    bundle_a_scenarios = {"lodging_success", "shop_success", "blocked_purchase", "paid_info"}
    missing_bundle_a = bundle_a_scenarios - new_names
    assert not missing_bundle_a, f"Bundle A scenarios not found in new registry: {missing_bundle_a}"

    # Check that Bundle B scenarios have been successfully ported
    bundle_b_scenarios = {
        "ambient_conversation", "autonomous_conversation", "conversation_discusses_event",
        "conversation_discusses_quest", "player_invited_conversation", "npc_replies_after_player_join",
        "player_requests_backed_quest_topic", "player_requests_unbacked_topic",
        "npc_response_uses_social_state", "rumor_seed_from_conversation", "rumor_signal_expires"
    }
    missing_bundle_b = bundle_b_scenarios - new_names
    assert not missing_bundle_b, f"Bundle B scenarios not found in new registry: {missing_bundle_b}"

    # Check that Bundle C scenarios have been successfully ported
    bundle_c_scenarios = {
        "npc_goal_influences_response_style", "npc_biography_shapes_bran_dialogue", "npc_biography_shapes_mira_dialogue",
        "npc_biography_blocks_unbacked_secret", "npc_roleplay_fallback_validation", "npc_history_records_player_reply",
        "npc_reputation_changes_response_style", "conversation_director_selects_biography_relevant_topic",
        "npc_schedule_populates_tavern_presence", "director_uses_presence_runtime", "scene_activity_uses_present_npc",
        "npc_knowledge_records_backed_quest_discussion", "npc_dialogue_recalls_prior_player_reply",
        "scene_continuity_tracks_recent_topic", "quest_access_backed_topic_partial_or_normal",
        "quest_access_unbacked_topic_denied", "player_reputation_polite_reply_improves_trust",
        "player_reputation_unbacked_pressure_adds_annoyance", "quest_rumor_seeded_from_backed_access",
        "quest_rumor_not_seeded_from_unbacked_claim", "npc_referral_suggests_present_relevant_npc",
        "consequence_signals_emit_bounded_social_signal"
    }
    missing_bundle_c = bundle_c_scenarios - new_names
    assert not missing_bundle_c, f"Bundle C scenarios not found in new registry: {missing_bundle_c}"

    # Check that Bundle D scenarios have been successfully ported
    bundle_d_scenarios = {
        "npc_file_profile_bran_loaded", "npc_evolution_bran_loses_tavern", "npc_evolution_reputation_threshold_trust",
        "npc_party_eligibility_after_bran_loses_tavern", "companion_join_intent_requires_player_request",
        "companion_acceptance_adds_bran_to_party", "npc_arc_continuity_tracks_bran_revenge_arc",
        "companion_presence_follow_party_aware_turns", "companion_commands_roles_boundaries",
        "companion_memory_personality_loyalty", "companion_quest_hooks_personal_arc_progression",
        "multi_companion_party_system", "dynamic_npc_profiles_character_cards",
        "dynamic_npc_profile_llm_draft_approval", "character_card_ui_profile_portrait_integration",
        "dynamic_npc_profile_generation_modes"
    }
    missing_bundle_d = bundle_d_scenarios - new_names
    assert not missing_bundle_d, f"Bundle D scenarios not found in new registry: {missing_bundle_d}"

    # Check that Bundle E scenarios have been successfully ported
    bundle_e_scenarios = {
        "general_interaction_runtime", "inventory_item_interaction_runtime", "inventory_item_model_stacking_weight_encumbrance",
        "inventory_containers_durability_repair", "inventory_consumables_ammo_equipment_stats",
        "inventory_crafting_recipes_materials", "inventory_loot_merchant_economy", "companion_inventory_auto_equip"
    }
    missing_bundle_e = bundle_e_scenarios - new_names
    assert not missing_bundle_e, f"Bundle E scenarios not found in new registry: {missing_bundle_e}"

    # Check that Bundle F scenarios have been successfully ported
    bundle_f_scenarios = {
        "combat_ui_payload_smoke", "combat_state_initiative_turn_gating", "combat_actions_damage_defeat",
        "companion_combat_participation", "enemy_combat_ai_party_defeat", "combat_llm_attack_narration",
        "combat_llm_defeat_narration", "combat_llm_party_defeat_narration", "combat_victory_grants_xp_once",
        "combat_flee_grants_no_loot_or_xp", "combat_post_victory_returns_to_world_actions",
        "combat_post_combat_clears_temporary_modifiers", "combat_victory_generates_loot_once",
        "combat_party_defeat_grants_no_player_loot", "manual_party_defeat_text_artifact_has_body"
    }
    missing_bundle_f = bundle_f_scenarios - new_names
    assert not missing_bundle_f, f"Bundle F scenarios not found in new registry: {missing_bundle_f}"

    # Check that Bundle G scenarios have been partially ported (infrastructure in place)
    # Note: Many Bundle G scenarios still need to be fully migrated, but the framework is ready
    bundle_g_sample_scenarios = {
        "combat_ui_payload_smoke", "combat_state_initiative_turn_gating", "combat_actions_damage_defeat",
        "companion_combat_participation", "enemy_combat_ai_party_defeat", "combat_llm_attack_narration",
        "combat_defend_reduces_next_incoming_attack", "combat_use_item_consumes_turn_and_applies_effect",
        "combat_flee_success_or_failure_is_authoritative", "combat_critical_hit_applies_bleeding",
        "combat_heavy_hit_applies_stunned", "combat_bleeding_ticks_damage"
    }
    missing_bundle_g_sample = bundle_g_sample_scenarios - new_names
    assert not missing_bundle_g_sample, f"Sample Bundle G scenarios not found in new registry: {missing_bundle_g_sample}"

    # Log progress on Bundle G migration
    all_bundle_g_scenarios = {
        "combat_defend_reduces_next_incoming_attack", "combat_use_item_consumes_turn_and_applies_effect",
        "combat_flee_success_or_failure_is_authoritative", "combat_critical_hit_applies_bleeding",
        "combat_heavy_hit_applies_stunned", "combat_bleeding_ticks_damage", "combat_stabilize_downed_companion",
        "combat_heal_downed_companion_revives", "combat_enemy_targets_low_hp_companion",
        "combat_enemy_avoids_downed_target", "combat_enemy_defends_when_low_hp_but_not_fleeing",
        "combat_enemy_flees_on_low_morale", "combat_enemy_stunned_skips_ai_intent",
        "combat_enemy_morale_victory_when_last_enemy_flees", "combat_start_bandit_encounter_from_archetype",
        "combat_generated_enemy_can_be_attacked", "combat_generated_enemy_ai_takes_turn",
        "combat_generated_encounter_victory_rewards", "combat_generated_encounter_victory_loot",
        "combat_scaling_easy_vs_hard_changes_enemy_budget", "combat_power_attack_adds_damage_bonus",
        "combat_unknown_ability_fails_safely", "combat_bleeding_slash_applies_bleeding",
        "combat_shield_bash_applies_stunned", "combat_ability_sets_cooldown",
        "combat_ability_on_cooldown_fails", "combat_ability_cooldown_ticks_down",
        "combat_enemy_brute_uses_power_attack", "combat_enemy_ability_sets_cooldown",
        "combat_enemy_does_not_use_ability_on_cooldown", "combat_enemy_stunned_does_not_use_ability",
        "combat_enemy_low_morale_flees_before_ability", "combat_companion_striker_attacks_enemy",
        "combat_companion_protector_defends_low_hp_player", "combat_player_commands_companion_attack",
        "combat_invalid_companion_command_fails_safely", "combat_downed_companion_cannot_act",
        "combat_melee_cannot_attack_far_target", "combat_reposition_moves_actor_near",
        "combat_ranged_enemy_attacks_from_backline", "combat_victory_emits_world_event_once",
        "combat_flee_emits_no_victory_world_event", "combat_bandit_victory_lowers_bandit_pressure"
    }
    bundle_g_progress = len(all_bundle_g_scenarios - (all_bundle_g_scenarios - new_names)) / len(all_bundle_g_scenarios) * 100
    print(f"Bundle G migration progress: {bundle_g_progress:.1f}% ({len(all_bundle_g_scenarios - (all_bundle_g_scenarios - new_names))}/{len(all_bundle_g_scenarios)} scenarios)")

    # Ensure no missing scenarios (migration complete)
    missing_names = all_old_names - new_names
    assert not missing_names, f"Missing scenarios: {missing_names}"

    print(f"Migration audit passed: All {len(new_names)} scenarios present in modular registry.")


def test_manual_scenario_registry_includes_memory_l7_l9_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_MEMORY_L7_L9_SCENARIO_NAMES - names

    assert not missing, f"Missing L7-L9 memory scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_social_l10_l12_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_SOCIAL_L10_L12_SCENARIO_NAMES - names

    assert not missing, f"Missing L10-L12 social scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_quest_puzzle_l13_l15_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_QUEST_PUZZLE_L13_L15_SCENARIO_NAMES - names

    assert not missing, f"Missing L13-L15 quest/puzzle scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_story_m1_m3_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_STORY_M1_M3_SCENARIO_NAMES - names

    assert not missing, f"Missing M1-M3 story scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_story_event_m4_m6_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_STORY_EVENT_M4_M6_SCENARIO_NAMES - names

    assert not missing, f"Missing M4-M6 story event scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_escalation_m7_m9_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_ESCALATION_M7_M9_SCENARIO_NAMES - names

    assert not missing, f"Missing M7-M9 escalation scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_story_pack_m13_m15_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_STORY_PACK_M13_M15_SCENARIO_NAMES - names

    assert not missing, f"Missing M13-M15 story pack scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_dialogue_m16_m18_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_DIALOGUE_M16_M18_SCENARIO_NAMES - names

    assert not missing, f"Missing M16-M18 dialogue scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_campaign_director_m22_m24_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_CAMPAIGN_DIRECTOR_M22_M24_SCENARIO_NAMES - names

    assert not missing, f"Missing M22-M24 campaign director scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_story_event_queue_m25_m27_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_STORY_EVENT_QUEUE_M25_M27_SCENARIO_NAMES - names

    assert not missing, f"Missing M25-M27 story event queue scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_companion_m28_m30_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_COMPANION_M28_M30_SCENARIO_NAMES - names

    assert not missing, f"Missing M28-M30 companion scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_campaign_journal_m31_m33_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_CAMPAIGN_JOURNAL_M31_M33_SCENARIO_NAMES - names

    assert not missing, f"Missing M31-M33 campaign journal scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_story_authoring_approval_m37_m39_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_STORY_AUTHORING_APPROVAL_M37_M39_SCENARIO_NAMES - names

    assert not missing, f"Missing M37-M39 story authoring approval scenarios: {sorted(missing)}"


def test_manual_scenario_registry_includes_story_arc_milestones_m46_m48_names():
    names = set(build_service_scenarios().keys())
    missing = EXPECTED_STORY_ARC_MILESTONES_M46_M48_SCENARIO_NAMES - names

    assert not missing, f"Missing M46-M48 story arc milestone scenarios: {sorted(missing)}"
