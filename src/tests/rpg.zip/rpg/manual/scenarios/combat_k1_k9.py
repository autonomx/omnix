from __future__ import annotations

from typing import Any, Dict

COMBAT_K1_K9_SCENARIOS: Dict[str, Dict[str, Any]] = {
    "combat_defend_reduces_next_incoming_attack": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
            "npc_file_profiles_enabled": True,
            "npc_evolution_enabled": True,
            "min_ticks_between_conversations": 0,
            "thread_cooldown_ticks": 0
        },
        "setup_interaction_state": {
            "scene_items": [],
            "scene_objects": [],
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []}
        },
        "turns": [
            "I attack the bandit.",
            "__manual_force_player_combat_turn__",
            "I defend."
        ]
    },
    "combat_use_item_consumes_turn_and_applies_effect": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
            "npc_file_profiles_enabled": True,
            "npc_evolution_enabled": True,
            "min_ticks_between_conversations": 0,
            "thread_cooldown_ticks": 0
        },
        "setup_interaction_state": {
            "scene_items": [],
            "scene_objects": [],
            "player_location_id": "loc_tavern_road",
            "player_hp": 5,
            "player_max_hp": 20,
            "player_inventory": {
                "items": [
                    {
                        "item_id": "item:minor_healing_potion",
                        "definition_id": "item:minor_healing_potion",
                        "name": "minor healing potion",
                        "aliases": ["potion", "healing potion"],
                        "qty": 1,
                        "quantity": 1
                    }
                ],
                "equipment": {},
                "carry_capacity": 50.0
            },
            "party_state": {"max_size": 4, "companions": []}
        },
        "turns": [
            "I attack the bandit.",
            "__manual_force_player_combat_turn__",
            "I drink the healing potion."
        ]
    },

    "combat_flee_success_or_failure_is_authoritative": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
            "npc_file_profiles_enabled": True,
            "npc_evolution_enabled": True,
            "min_ticks_between_conversations": 0,
            "thread_cooldown_ticks": 0
        },
        "setup_interaction_state": {
            "scene_items": [],
            "scene_objects": [],
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []}
        },
        "turns": [
            "I attack the bandit.",
            "__manual_force_player_combat_turn__",
            "I flee."
        ]
    },

    "combat_critical_hit_applies_bleeding": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "player",
                "force_next_attack_roll": 20,
                "initiative_order": [
                    {"actor_id": "player", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "enemy:bandit_1", "initiative": 1, "roll": 1, "bonus": 0},
                ],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 12,
                        "max_hp": 12,
                        "defense": 10,
                        "armor": 0,
                        "status": "active",
                    },
                },
                "combat_log": [],
                "source": "manual_condition_test",
            },
        },
        "turns": ["I attack the bandit."],
    },

    "combat_heavy_hit_applies_stunned": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "player",
                "force_next_damage": 6,
                "initiative_order": [
                    {"actor_id": "player", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "enemy:bandit_1", "initiative": 1, "roll": 1, "bonus": 0},
                ],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 12,
                        "max_hp": 12,
                        "defense": 10,
                        "armor": 0,
                        "status": "active",
                    },
                },
                "combat_log": [],
                "source": "manual_condition_test",
            },
        },
        "turns": ["I attack the bandit."],
    },

    "combat_bleeding_ticks_damage": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "enemy:bandit_1",
                "initiative_order": [
                    {"actor_id": "enemy:bandit_1", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "player", "initiative": 1, "roll": 1, "bonus": 0},
                ],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 8,
                        "max_hp": 12,
                        "status": "active",
                        "status_effects": [
                            {
                                "effect_id": "effect:bleeding:enemy:bandit_1:test",
                                "kind": "bleeding",
                                "source": "combat",
                                "source_actor_id": "player",
                                "target_actor_id": "enemy:bandit_1",
                                "duration_turns": 2,
                                "stacks": 1,
                                "magnitude": 1,
                                "tick_timing": "start_of_turn",
                            }
                        ],
                    },
                },
                "combat_log": [],
                "source": "manual_condition_test",
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_stabilize_downed_companion": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {
                "max_size": 4,
                "companions": [{"npc_id": "npc:bran", "name": "Bran"}],
            },
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "player",
                "initiative_order": [
                    {"actor_id": "player", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "npc:bran", "initiative": 10, "roll": 10, "bonus": 0},
                ],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                    "npc:bran": {
                        "actor_id": "npc:bran",
                        "side": "party",
                        "name": "Bran",
                        "hp": 0,
                        "max_hp": 14,
                        "status": "downed",
                        "status_effects": [
                            {
                                "effect_id": "effect:downed:npc:bran:test",
                                "kind": "downed",
                                "source": "combat",
                                "source_actor_id": "enemy:bandit_1",
                                "target_actor_id": "npc:bran",
                                "duration_turns": 999,
                                "stacks": 1,
                                "magnitude": 1,
                                "tick_timing": "none",
                            }
                        ],
                    },
                },
                "combat_log": [],
                "source": "manual_recovery_test",
            },
        },
        "turns": ["I stabilize Bran."],
    },

    "combat_heal_downed_companion_revives": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {
                "items": [
                    {
                        "item_id": "item:minor_healing_potion",
                        "definition_id": "item:minor_healing_potion",
                        "name": "minor healing potion",
                        "aliases": ["potion", "healing potion"],
                        "qty": 1,
                        "quantity": 1,
                    }
                ],
                "equipment": {},
                "carry_capacity": 50.0,
            },
            "party_state": {
                "max_size": 4,
                "companions": [{"npc_id": "npc:bran", "name": "Bran"}],
            },
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "player",
                "initiative_order": [
                    {"actor_id": "player", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "npc:bran", "initiative": 10, "roll": 10, "bonus": 0},
                ],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                    "npc:bran": {
                        "actor_id": "npc:bran",
                        "side": "party",
                        "name": "Bran",
                        "hp": 0,
                        "max_hp": 14,
                        "status": "downed",
                        "status_effects": [
                            {
                                "effect_id": "effect:downed:npc:bran:test",
                                "kind": "downed",
                                "source": "combat",
                                "source_actor_id": "enemy:bandit_1",
                                "target_actor_id": "npc:bran",
                                "duration_turns": 999,
                                "stacks": 1,
                                "magnitude": 1,
                                "tick_timing": "none",
                            },
                            {
                                "effect_id": "effect:unconscious:npc:bran:test",
                                "kind": "unconscious",
                                "source": "combat",
                                "source_actor_id": "enemy:bandit_1",
                                "target_actor_id": "npc:bran",
                                "duration_turns": 999,
                                "stacks": 1,
                                "magnitude": 1,
                                "tick_timing": "none",
                            },
                        ],
                    },
                },
                "combat_log": [],
                "source": "manual_recovery_test",
            },
        },
        "turns": ["I use the healing potion on Bran."],
    },

    "combat_enemy_targets_low_hp_companion": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {
                "max_size": 4,
                "companions": [{"npc_id": "npc:bran", "name": "Bran"}],
            },
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "enemy:bandit_1",
                "initiative_order": [
                    {"actor_id": "enemy:bandit_1", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "player", "initiative": 10, "roll": 10, "bonus": 0},
                    {"actor_id": "npc:bran", "initiative": 5, "roll": 5, "bonus": 0},
                ],
                "participants": {
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 12,
                        "max_hp": 12,
                        "status": "active",
                        "morale_threshold": 20,
                    },
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                    "npc:bran": {
                        "actor_id": "npc:bran",
                        "side": "party",
                        "name": "Bran",
                        "hp": 3,
                        "max_hp": 14,
                        "status": "active",
                    },
                },
                "combat_log": [],
                "source": "manual_enemy_ai_test",
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_enemy_avoids_downed_target": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {
                "max_size": 4,
                "companions": [{"npc_id": "npc:bran", "name": "Bran"}],
            },
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "enemy:bandit_1",
                "initiative_order": [
                    {"actor_id": "enemy:bandit_1", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "npc:bran", "initiative": 10, "roll": 10, "bonus": 0},
                    {"actor_id": "player", "initiative": 5, "roll": 5, "bonus": 0},
                ],
                "participants": {
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 12,
                        "max_hp": 12,
                        "status": "active",
                        "morale_threshold": 20,
                    },
                    "npc:bran": {
                        "actor_id": "npc:bran",
                        "side": "party",
                        "name": "Bran",
                        "hp": 0,
                        "max_hp": 14,
                        "status": "downed",
                        "status_effects": [
                            {
                                "effect_id": "effect:downed:npc:bran:test",
                                "kind": "downed",
                                "source": "combat",
                                "source_actor_id": "enemy:bandit_1",
                                "target_actor_id": "npc:bran",
                                "duration_turns": 999,
                                "stacks": 1,
                                "magnitude": 1,
                                "tick_timing": "none",
                            }
                        ],
                    },
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                },
                "combat_log": [],
                "source": "manual_enemy_ai_test",
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_enemy_defends_when_low_hp_but_not_fleeing": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "enemy:bandit_1",
                "initiative_order": [
                    {"actor_id": "enemy:bandit_1", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "player", "initiative": 10, "roll": 10, "bonus": 0},
                ],
                "participants": {
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 4,
                        "max_hp": 12,
                        "status": "active",
                        "morale_threshold": 5,
                    },
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                },
                "combat_log": [],
                "source": "manual_enemy_ai_test",
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_enemy_flees_on_low_morale": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "enemy:bandit_1",
                "initiative_order": [
                    {"actor_id": "enemy:bandit_1", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "player", "initiative": 10, "roll": 10, "bonus": 0},
                ],
                "participants": {
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 1,
                        "max_hp": 12,
                        "status": "active",
                        "morale_threshold": 80,
                    },
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                },
                "combat_log": [],
                "source": "manual_enemy_ai_test",
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_enemy_stunned_skips_ai_intent": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "enemy:bandit_1",
                "initiative_order": [
                    {"actor_id": "enemy:bandit_1", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "player", "initiative": 10, "roll": 10, "bonus": 0},
                ],
                "participants": {
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 8,
                        "max_hp": 12,
                        "status": "active",
                        "morale_threshold": 20,
                        "status_effects": [
                            {
                                "effect_id": "effect:stunned:enemy:bandit_1:test",
                                "kind": "stunned",
                                "source": "combat",
                                "source_actor_id": "player",
                                "target_actor_id": "enemy:bandit_1",
                                "duration_turns": 1,
                                "stacks": 1,
                                "magnitude": 1,
                                "tick_timing": "none",
                            }
                        ],
                    },
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                },
                "combat_log": [],
                "source": "manual_enemy_ai_test",
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_enemy_morale_victory_when_last_enemy_flees": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "round": 1,
                "turn_index": 0,
                "current_actor_id": "enemy:bandit_1",
                "initiative_order": [
                    {"actor_id": "enemy:bandit_1", "initiative": 20, "roll": 20, "bonus": 0},
                    {"actor_id": "player", "initiative": 10, "roll": 10, "bonus": 0},
                ],
                "participants": {
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 1,
                        "max_hp": 12,
                        "status": "active",
                        "morale_threshold": 80,
                    },
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                },
                "combat_log": [],
                "source": "manual_enemy_ai_test",
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_start_bandit_encounter_from_archetype": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
        },
        "turns": ["__manual_start_encounter__:bandit_easy"],
    },

    "combat_generated_enemy_can_be_attacked": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
        },
        "turns": [
            "__manual_start_encounter__:bandit_easy",
            "I attack the bandit grunt.",
        ],
    },

    "combat_generated_enemy_ai_takes_turn": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
        },
        "turns": [
            "__manual_start_encounter__:bandit_easy",
            "__manual_force_enemy_turn__",
            "__manual_resolve_current_combat_actor__",
        ],
    },

    "combat_generated_encounter_victory_rewards": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
        },
        "turns": [
            "__manual_start_encounter__:bandit_easy",
            "__manual_reduce_first_enemy_hp__:1",
            "__manual_force_next_attack_roll__:20",
            "__manual_force_next_damage__:1",
            "I attack the bandit grunt.",
        ],
    },

    "combat_generated_encounter_victory_loot": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
        },
        "turns": [
            "__manual_start_encounter__:bandit_easy",
            "__manual_reduce_first_enemy_hp__:1",
            "__manual_force_next_attack_roll__:20",
            "__manual_force_next_damage__:1",
            "I attack the bandit grunt.",
        ],
    },

    "combat_scaling_easy_vs_hard_changes_enemy_budget": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {
            "enabled": True,
            "autonomous_ticks_enabled": False,
            "frequency": "never",
            "conversation_chance_percent": 0,
            "allow_player_invited": False,
            "player_inclusion_chance_percent": 0,
        },
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
        },
        "turns": [
            "__manual_start_encounter__:bandit_easy",
            "__manual_start_encounter__:bandit_hard",
        ],
    },

    "combat_power_attack_adds_damage_bonus": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "damage_min": 1, "damage_max": 4, "status": "active"},
                    "enemy:bandit_1": {"actor_id": "enemy:bandit_1", "side": "enemy", "name": "Bandit", "hp": 12, "max_hp": 12, "status": "active"},
                },
            },
        },
        "turns": ["I use power attack on the bandit."],
    },

    "combat_unknown_ability_fails_safely": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "damage_min": 1, "damage_max": 4, "status": "active"},
                    "enemy:bandit_1": {"actor_id": "enemy:bandit_1", "side": "enemy", "name": "Bandit", "hp": 12, "max_hp": 12, "status": "active"},
                },
            },
        },
        "turns": ["I use unknown ability on the bandit."],
    },

    "combat_bleeding_slash_applies_bleeding": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "damage_min": 1, "damage_max": 4, "status": "active"},
                    "enemy:bandit_1": {"actor_id": "enemy:bandit_1", "side": "enemy", "name": "Bandit", "hp": 12, "max_hp": 12, "status": "active"},
                },
            },
        },
        "turns": ["I use bleeding slash on the bandit."],
    },

    "combat_shield_bash_applies_stunned": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "damage_min": 1, "damage_max": 4, "status": "active"},
                    "enemy:bandit_1": {"actor_id": "enemy:bandit_1", "side": "enemy", "name": "Bandit", "hp": 12, "max_hp": 12, "status": "active"},
                },
            },
        },
        "turns": ["I use shield bash on the bandit."],
    },

    "combat_ability_sets_cooldown": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "damage_min": 1, "damage_max": 4, "status": "active"},
                    "enemy:bandit_1": {"actor_id": "enemy:bandit_1", "side": "enemy", "name": "Bandit", "hp": 12, "max_hp": 12, "status": "active"},
                },
            },
        },
        "turns": ["I use power attack on the bandit."],
    },

    "combat_ability_on_cooldown_fails": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "damage_min": 1, "damage_max": 4, "status": "active", "ability_cooldowns": {"ability:power_attack": 2}},
                    "enemy:bandit_1": {"actor_id": "enemy:bandit_1", "side": "enemy", "name": "Bandit", "hp": 12, "max_hp": 12, "status": "active"},
                },
            },
        },
        "turns": ["I use power attack on the bandit."],
    },

    "combat_ability_cooldown_ticks_down": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "damage_min": 1, "damage_max": 4, "status": "active", "ability_cooldowns": {"ability:power_attack": 2}},
                    "enemy:bandit_1": {"actor_id": "enemy:bandit_1", "side": "enemy", "name": "Bandit", "hp": 12, "max_hp": 12, "status": "active"},
                },
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_enemy_brute_uses_power_attack": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "enemy:brute_1",
                "initiative_order": [{"actor_id": "enemy:brute_1", "initiative": 20}, {"actor_id": "player", "initiative": 1}],
                "participants": {
                    "enemy:brute_1": {"actor_id": "enemy:brute_1", "side": "enemy", "name": "Brute", "hp": 18, "max_hp": 18, "damage_min": 2, "damage_max": 6, "tags": ["brute"], "status": "active", "morale_threshold": 5},
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "status": "active"},
                },
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_enemy_ability_sets_cooldown": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "enemy:brute_1",
                "initiative_order": [{"actor_id": "enemy:brute_1", "initiative": 20}, {"actor_id": "player", "initiative": 1}],
                "participants": {
                    "enemy:brute_1": {"actor_id": "enemy:brute_1", "side": "enemy", "name": "Brute", "hp": 18, "max_hp": 18, "damage_min": 2, "damage_max": 6, "tags": ["brute"], "status": "active", "morale_threshold": 5},
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "status": "active"},
                },
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_enemy_does_not_use_ability_on_cooldown": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "enemy:brute_1",
                "initiative_order": [{"actor_id": "enemy:brute_1", "initiative": 20}, {"actor_id": "player", "initiative": 1}],
                "participants": {
                    "enemy:brute_1": {"actor_id": "enemy:brute_1", "side": "enemy", "name": "Brute", "hp": 18, "max_hp": 18, "damage_min": 2, "damage_max": 6, "tags": ["brute"], "status": "active", "morale_threshold": 5, "ability_cooldowns": {"ability:power_attack": 2}},
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "status": "active"},
                },
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_enemy_stunned_does_not_use_ability": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "enemy:brute_1",
                "initiative_order": [{"actor_id": "enemy:brute_1", "initiative": 20}, {"actor_id": "player", "initiative": 1}],
                "participants": {
                    "enemy:brute_1": {"actor_id": "enemy:brute_1", "side": "enemy", "name": "Brute", "hp": 18, "max_hp": 18, "damage_min": 2, "damage_max": 6, "tags": ["brute"], "status": "active", "morale_threshold": 5, "status_effects": [{"effect_id": "effect:stunned:enemy:brute_1:test", "kind": "stunned", "target_actor_id": "enemy:brute_1", "duration_turns": 1, "stacks": 1, "magnitude": 1, "tick_timing": "none"}]},
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "status": "active"},
                },
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_enemy_low_morale_flees_before_ability": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "enemy:brute_1",
                "initiative_order": [{"actor_id": "enemy:brute_1", "initiative": 20}, {"actor_id": "player", "initiative": 1}],
                "participants": {
                    "enemy:brute_1": {"actor_id": "enemy:brute_1", "side": "enemy", "name": "Brute", "hp": 1, "max_hp": 18, "damage_min": 2, "damage_max": 6, "tags": ["brute"], "status": "active", "morale_threshold": 80},
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "status": "active"},
                },
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_companion_striker_attacks_enemy": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": [{"npc_id": "npc:bran", "name": "Bran"}]},
            "combat_state": {
                "active": True,
                "current_actor_id": "npc:bran",
                "initiative_order": [{"actor_id": "npc:bran", "initiative": 20}, {"actor_id": "player", "initiative": 10}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "npc:bran": {"actor_id": "npc:bran", "side": "party", "name": "Bran", "hp": 14, "max_hp": 14, "damage_min": 1, "damage_max": 4, "combat_role": "striker", "status": "active"},
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "status": "active"},
                    "enemy:bandit_1": {"actor_id": "enemy:bandit_1", "side": "enemy", "name": "Bandit", "hp": 8, "max_hp": 8, "status": "active"},
                },
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_companion_protector_defends_low_hp_player": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 5,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": [{"npc_id": "npc:bran", "name": "Bran"}]},
            "combat_state": {
                "active": True,
                "current_actor_id": "npc:bran",
                "initiative_order": [{"actor_id": "npc:bran", "initiative": 20}, {"actor_id": "player", "initiative": 10}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "npc:bran": {"actor_id": "npc:bran", "side": "party", "name": "Bran", "hp": 14, "max_hp": 14, "combat_role": "protector", "status": "active"},
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 5, "max_hp": 20, "status": "active"},
                    "enemy:bandit_1": {"actor_id": "enemy:bandit_1", "side": "enemy", "name": "Bandit", "hp": 8, "max_hp": 8, "status": "active"},
                },
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_player_commands_companion_attack": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": [{"npc_id": "npc:bran", "name": "Bran"}]},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "npc:bran", "initiative": 10}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "status": "active"},
                    "npc:bran": {"actor_id": "npc:bran", "side": "party", "name": "Bran", "hp": 14, "max_hp": 14, "damage_min": 1, "damage_max": 4, "combat_role": "striker", "status": "active"},
                    "enemy:bandit_1": {"actor_id": "enemy:bandit_1", "side": "enemy", "name": "Bandit", "hp": 8, "max_hp": 8, "status": "active"},
                },
            },
        },
        "turns": ["Bran, attack the bandit."],
    },

    "combat_invalid_companion_command_fails_safely": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": [{"npc_id": "npc:bran", "name": "Bran"}]},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "npc:bran", "initiative": 10}],
                "participants": {
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "status": "active"},
                    "npc:bran": {"actor_id": "npc:bran", "side": "party", "name": "Bran", "hp": 14, "max_hp": 14, "combat_role": "striker", "status": "active"},
                },
            },
        },
        "turns": ["Bran, dance at the bandit."],
    },

    "combat_downed_companion_cannot_act": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": [{"npc_id": "npc:bran", "name": "Bran"}]},
            "combat_state": {
                "active": True,
                "current_actor_id": "npc:bran",
                "initiative_order": [{"actor_id": "npc:bran", "initiative": 20}, {"actor_id": "player", "initiative": 10}],
                "participants": {
                    "npc:bran": {"actor_id": "npc:bran", "side": "party", "name": "Bran", "hp": 0, "max_hp": 14, "status": "downed", "combat_role": "striker"},
                    "player": {"actor_id": "player", "side": "party", "name": "You", "hp": 20, "max_hp": 20, "status": "active"},
                },

            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    # ---- Bundle G: positioning, ranged, world events ----

    "combat_melee_cannot_attack_far_target": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                        "position": {"x": 0, "y": 0},
                    },
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 8,
                        "max_hp": 8,
                        "status": "active",
                        "position": {"x": 50, "y": 50},
                    },
                },
            },
        },
        "turns": ["attack bandit"],
    },

    "combat_ranged_enemy_attacks_from_backline": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "enemy:archer_1",
                "initiative_order": [{"actor_id": "enemy:archer_1", "initiative": 20}, {"actor_id": "player", "initiative": 10}],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                        "position": {"x": 0, "y": 0},
                    },
                    "enemy:archer_1": {
                        "actor_id": "enemy:archer_1",
                        "side": "enemy",
                        "name": "Archer",
                        "hp": 8,
                        "max_hp": 8,
                        "status": "active",
                        "position": {"x": 30, "y": 30},
                        "tags": ["ranged"],
                        "damage_min": 1,
                        "damage_max": 4,
                    },
                },
            },
        },
        "turns": ["__manual_resolve_current_combat_actor__"],
    },

    "combat_reposition_moves_actor_near": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                        "position": {"x": 0, "y": 0},
                    },
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 8,
                        "max_hp": 8,
                        "status": "active",
                        "position": {"x": 30, "y": 30},
                    },
                },
            },
        },
        "turns": ["move closer to bandit"],
    },

    "combat_victory_emits_world_event_once": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                        "damage_min": 3,
                        "damage_max": 6,
                    },
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 2,
                        "max_hp": 2,
                        "status": "active",
                    },
                },
            },
        },
        "turns": ["attack bandit"],
    },

    "combat_flee_emits_no_victory_world_event": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                    },
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 8,
                        "max_hp": 8,
                        "status": "active",
                    },
                },
            },
        },
        "turns": ["flee"],
    },

    "combat_bandit_victory_lowers_bandit_pressure": {
        "currency": {"gold": 0, "silver": 0, "copper": 0},
        "conversation_settings": {"enabled": True, "autonomous_ticks_enabled": False, "frequency": "never", "conversation_chance_percent": 0},
        "setup_interaction_state": {
            "player_location_id": "loc_tavern_road",
            "player_hp": 20,
            "player_max_hp": 20,
            "player_inventory": {"items": [], "equipment": {}, "carry_capacity": 50.0},
            "party_state": {"max_size": 4, "companions": []},
            "combat_state": {
                "active": True,
                "current_actor_id": "player",
                "initiative_order": [{"actor_id": "player", "initiative": 20}, {"actor_id": "enemy:bandit_1", "initiative": 1}],
                "participants": {
                    "player": {
                        "actor_id": "player",
                        "side": "party",
                        "name": "You",
                        "hp": 20,
                        "max_hp": 20,
                        "status": "active",
                        "damage_min": 3,
                        "damage_max": 6,
                    },
                    "enemy:bandit_1": {
                        "actor_id": "enemy:bandit_1",
                        "side": "enemy",
                        "name": "Bandit",
                        "hp": 2,
                        "max_hp": 2,
                        "status": "active",
                        "tags": ["bandit"],
                    },
                },
            },
        },
        "turns": ["attack bandit"],
    },
}
