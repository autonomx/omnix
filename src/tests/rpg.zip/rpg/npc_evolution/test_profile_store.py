import json

from app.rpg.npc_evolution.profile_store import (
    load_npc_profile,
    persist_npc_evolution_profiles,
    profile_path_for_npc,
)


def test_persist_npc_evolution_profiles_writes_bounded_profile(tmp_path):
    runtime_state = {
        "npc_evolution": {
            "signals": [
                {
                    "signal_id": "s1",
                    "npc_id": "Bran",
                    "kind": "memory",
                    "turn_index": 2,
                    "summary": "Bran remembers the player.",
                    "source": "deferred_advisory_promotion",
                    "consumed": True,
                }
            ],
            "arcs": {
                "Bran": {
                    "npc_id": "Bran",
                    "arc_stage": "stable",
                    "axes": {"trust": 1},
                    "memories": [
                        {
                            "signal_id": "s1",
                            "summary": "Bran remembers the player.",
                        }
                    ],
                    "future_hooks": [],
                    "world_signals": [],
                    "semantic_intents": [],
                    "milestones": [],
                }
            },
        }
    }

    result = persist_npc_evolution_profiles(runtime_state=runtime_state, root=tmp_path)

    assert result["ok"] is True
    assert result["written_count"] == 1

    profile_path = tmp_path / "bran.json"
    assert profile_path.exists()
    data = json.loads(profile_path.read_text(encoding="utf-8"))
    assert data["npc_id"] == "Bran"
    assert data["evolution"]["axes"]["trust"] == 1
    assert data["evolution"]["signals_applied"][0]["signal_id"] == "s1"


def test_persist_npc_evolution_profiles_is_idempotent(tmp_path):
    runtime_state = {
        "npc_evolution": {
            "signals": [
                {
                    "signal_id": "s1",
                    "npc_id": "Bran",
                    "kind": "future_hook",
                    "turn_index": 2,
                    "summary": "Bran may answer later.",
                    "source": "deferred_advisory_promotion",
                    "consumed": True,
                }
            ],
            "arcs": {
                "Bran": {
                    "npc_id": "Bran",
                    "arc_stage": "stable",
                    "axes": {},
                    "future_hooks": [{"signal_id": "s1", "summary": "Bran may answer later."}],
                }
            },
        }
    }

    persist_npc_evolution_profiles(runtime_state=runtime_state, root=tmp_path)
    persist_npc_evolution_profiles(runtime_state=runtime_state, root=tmp_path)
    profile = load_npc_profile("Bran", root=tmp_path)

    assert len(profile["evolution"]["future_hooks"]) == 1
    assert len(profile["evolution"]["signals_applied"]) == 1


def test_profile_path_collapses_prefixed_npc_id(tmp_path):
    assert profile_path_for_npc("npc:bran", root=tmp_path).name == "bran.json"


def test_persist_removes_legacy_prefixed_profile(tmp_path):
    legacy_path = tmp_path / "npc_bran.json"
    legacy_path.write_text("{}", encoding="utf-8")
    runtime_state = {
        "npc_evolution": {
            "signals": [
                {
                    "signal_id": "s1",
                    "npc_id": "Bran",
                    "kind": "memory",
                    "summary": "Bran remembers.",
                    "consumed": True,
                }
            ],
            "arcs": {
                "Bran": {
                    "npc_id": "Bran",
                    "arc_stage": "stable",
                    "axes": {},
                    "memories": [{"signal_id": "s1", "summary": "Bran remembers."}],
                }
            },
        }
    }

    result = persist_npc_evolution_profiles(runtime_state=runtime_state, root=tmp_path)

    assert result["ok"] is True
    assert (tmp_path / "bran.json").exists()
    assert not legacy_path.exists()
    assert result["written"][0]["removed_legacy_paths"]


def test_persist_npc_evolution_profiles_writes_milestones(tmp_path):
    runtime_state = {
        "npc_evolution": {
            "signals": [
                {
                    "signal_id": "s1",
                    "npc_id": "Bran",
                    "kind": "relationship_delta",
                    "turn_index": 2,
                    "summary": "Bran trusts the player more.",
                    "source": "deferred_advisory_promotion",
                    "consumed": True,
                }
            ],
            "arcs": {
                "Bran": {
                    "npc_id": "Bran",
                    "arc_stage": "trusting",
                    "axes": {"trust": 4},
                    "milestones": [
                        {
                            "milestone_id": "m1",
                            "turn_index": 2,
                            "from": "stable",
                            "to": "trusting",
                            "reason": "relationship_delta:trust",
                            "signal_id": "s1",
                        }
                    ],
                }
            },
        }
    }

    result = persist_npc_evolution_profiles(runtime_state=runtime_state, root=tmp_path)
    profile = load_npc_profile("Bran", root=tmp_path)

    assert result["ok"] is True
    assert profile["evolution"]["arc_stage"] == "trusting"
    assert profile["evolution"]["milestones"][0]["milestone_id"] == "m1"