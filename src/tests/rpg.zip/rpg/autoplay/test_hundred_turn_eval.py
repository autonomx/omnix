from tests.rpg.autoplay.hundred_turn_eval import (
    canonical_semantic_pair_from_turn,
    summarize_action_diversity,
    summarize_hundred_turn_eval,
    summarize_long_run_warnings,
    summarize_progress_timeline,
)


def _row(turn, action="Ask Bran about the witness.", semantic="ask", target="Bran", story=True):
    return {
        "turn_index": turn,
        "player_action": action,
        "turn_contract": {
            "player_input": action,
            "semantic_action": {"type": semantic, "target": target},
            "resolved_result": {"summary": "Bran mentioned the witness." if story else ""},
        },
        "runtime_state": {
            "player_journal": {
                "entries": [{"entry_id": f"journal:turn:{turn}"}] if turn % 4 == 0 else []
            },
            "quest_progress": {
                "quests": {
                    "quest:witness_search": {
                        "title": "Witness Search",
                        "status": "active",
                    }
                }
            },
            "npc_evolution": {
                "signals": [{"signal_id": f"s{turn}"}] if story else []
            },
        },
        "combined_background_llm_result": {
            "narration": "Bran lowered his voice." if story else ""
        },
    }


def test_action_diversity_detects_repeated_semantic_target_streak():
    transcript = [_row(i, semantic="ask", target="Bran") for i in range(1, 7)]

    summary = summarize_action_diversity(transcript)

    assert summary["turns"] == 6
    assert summary["max_same_semantic_target_streak"]["streak"] == 6
    assert summary["max_same_semantic_target_streak"]["value"] == "ask:Bran"


def test_action_diversity_reads_semantic_action_v2_and_normalizes_target():
    transcript = [
        {
            "turn_index": 1,
            "player_action": "Ask the innkeeper about the witness.",
            "turn_contract": {
                "semantic_action_v2": {
                    "type": "Ask",
                    "target": "npc:Bran",
                }
            },
            "runtime_state": {
                "npc_evolution": {
                    "loaded_profiles": {
                        "Bran": {"profile": {"npc_id": "Bran", "name": "Bran"}}
                    }
                }
            },
        }
    ]

    summary = summarize_action_diversity(transcript)

    assert summary["top_semantic_actions"][0][0] == "ask"
    assert summary["top_targets"][0][0] == "Bran"
    assert summary["top_semantic_targets"][0][0] == "ask:Bran"
    assert summary["unknown_semantic_count"] == 0


def test_action_diversity_reads_fast_semantic_action_record():
    transcript = [
        {
            "turn_index": 1,
            "player_action": "Listen for rumors.",
            "fast_semantic_action": {
                "semantic_action_type": "Observe",
                "target_name": "Rusty Flagon Tavern",
            },
        }
    ]

    summary = summarize_action_diversity(transcript)

    assert summary["top_semantic_actions"][0][0] == "observe"
    assert summary["top_targets"][0][0] == "Rusty Flagon Tavern"


def test_action_diversity_falls_back_to_action_text_when_structured_missing():
    transcript = [
        {
            "turn_index": 1,
            "player_action": "Ask Bran about the missing witness.",
            "simulation_state": {
                "scene": {"nearby_npcs": ["Bran"]},
                "npc_progression_state": {"npcs": {"Bran": {"name": "Bran", "role": "innkeeper"}}},
            },
        }
    ]

    summary = summarize_action_diversity(transcript)

    assert summary["top_semantic_actions"][0][0] == "ask"
    assert summary["top_targets"][0][0] == "Bran"
    assert summary["unknown_semantic_count"] == 0


def test_progress_timeline_computes_progress_rates():
    transcript = [_row(i, story=True) for i in range(1, 5)]

    summary = summarize_progress_timeline(transcript)

    assert summary["turns"] == 4
    assert summary["meaningful_progress_turns"] >= 1
    assert summary["story_beat_turns"] == 4
    assert summary["max_storyless_streak"] == 0


def test_progress_timeline_detects_noop_streak():
    transcript = []
    for i in range(1, 5):
        row = _row(i, story=False)
        row["turn_contract"]["resolved_result"] = {"reason": "target_not_found"}
        transcript.append(row)

    summary = summarize_progress_timeline(transcript)

    assert summary["noop_turns"] == 4
    assert summary["max_noop_streak"] == 4


def test_long_run_warnings_become_errors_in_strict_mode():
    transcript = [_row(i, semantic="ask", target="Bran", story=False) for i in range(1, 101)]
    action = summarize_action_diversity(transcript)
    progress = summarize_progress_timeline(transcript)

    warnings = summarize_long_run_warnings(
        transcript=transcript,
        action_diversity_summary=action,
        progress_timeline_summary=progress,
        console_log_summary={"turn_error_count": 0},
        manual_turn_error_summary={"error_count": 0},
        turns_for_strict_gates=100,
    )

    assert warnings["strict_100_turn_mode"] is True
    assert warnings["ok"] is False
    assert warnings["error_count"] >= 1


def test_hundred_turn_eval_smoke_mode_allows_short_runs():
    transcript = [_row(i) for i in range(1, 9)]

    summary = summarize_hundred_turn_eval(
        transcript=transcript,
        summary={
            "console_log_summary": {"turn_error_count": 0},
            "manual_turn_error_summary": {"error_count": 0},
        },
        turns_for_strict_gates=100,
    )

    assert summary["readiness"] == "smoke"
    assert summary["strict_100_turn_mode"] is False
    assert "action_diversity_summary" in summary
    assert "progress_timeline_summary" in summary


def test_long_run_warning_flags_unknown_semantic_rate_in_strict_mode():
    transcript = [{"turn_index": i, "player_action": "Do something vague."} for i in range(1, 101)]
    action = summarize_action_diversity(transcript)
    progress = summarize_progress_timeline(transcript)

    warnings = summarize_long_run_warnings(
        transcript=transcript,
        action_diversity_summary=action,
        progress_timeline_summary=progress,
        console_log_summary={"turn_error_count": 0},
        manual_turn_error_summary={"error_count": 0},
        turns_for_strict_gates=100,
    )

    assert any(
        warning["code"] == "semantic_action_extraction_unknown_rate"
        for warning in warnings["warnings"]
    )


def test_canonical_semantic_pair_classifies_executable_witness_actions():
    row = {
        "player_action": "I inspect the tavern side door and nearby street for mud, torn cloth, boot prints, or signs of a hurried exit."
    }
    result = canonical_semantic_pair_from_turn(row)
    assert result["semantic_action"] == "inspect_witness_trail"
    assert result["target"] == "tavern_exit"
    assert result["ok"] is True

    row = {
        "player_action": "I leave the Rusty Flagon and follow the road outside, looking for fresh tracks or the cloaked traveler."
    }
    result = canonical_semantic_pair_from_turn(row)
    assert result["semantic_action"] == "follow_witness_trail"
    assert result["target"] == "road"
    assert result["ok"] is True


def test_canonical_semantic_pair_normalizes_command_label_ask_bran():
    result = canonical_semantic_pair_from_turn(
        {"player_action": "Ask Bran what they personally saw about the cloaked traveler"}
    )
    assert result["semantic_action"] == "ask_witness_lead"
    assert result["target"] == "Bran"
    assert result["ok"] is True