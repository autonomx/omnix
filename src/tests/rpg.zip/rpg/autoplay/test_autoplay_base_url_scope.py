import ast
from pathlib import Path


def _function_source_tree(path: str, function_name: str):
    source = Path(path).read_text(encoding="utf-8")
    tree = ast.parse(source)
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == function_name:
            return node
    raise AssertionError(f"Function not found: {function_name}")


def test_call_turn_runtime_accepts_base_url_argument():
    node = _function_source_tree("src/tests/rpg/autoplay_llm_campaign.py", "_call_turn_runtime")
    arg_names = [arg.arg for arg in node.args.kwonlyargs]

    assert "base_url" in arg_names


def test_run_real_rpg_turn_accepts_base_url_argument():
    node = _function_source_tree("src/tests/rpg/autoplay/turn_runtime.py", "run_real_rpg_turn")
    arg_names = [arg.arg for arg in node.args.kwonlyargs]

    assert "base_url" in arg_names


def test_run_autoplay_campaign_uses_resolved_base_url_not_bare_base_url():
    node = _function_source_tree("src/tests/rpg/autoplay_llm_campaign.py", "run_autoplay_campaign")

    assigned_names = {
        target.id
        for subnode in ast.walk(node)
        if isinstance(subnode, ast.Assign)
        for target in subnode.targets
        if isinstance(target, ast.Name)
    }
    assert "resolved_base_url" in assigned_names

    bad_loads = []
    for subnode in ast.walk(node):
        if isinstance(subnode, ast.Name) and subnode.id == "base_url" and isinstance(subnode.ctx, ast.Load):
            bad_loads.append((subnode.lineno, subnode.col_offset))

    assert bad_loads == []


def test_call_turn_runtime_passes_base_url_without_name_error(monkeypatch):
    from tests.rpg import autoplay_llm_campaign

    captured = {}

    def fake_run_real_rpg_turn(**kwargs):
        captured.update(kwargs)
        return {
            "ok": False,
            "reason": "fake_no_runtime",
            "simulation_state": kwargs["simulation_state"],
            "turn_contract": {},
            "narration": "",
        }

    monkeypatch.setattr(
        autoplay_llm_campaign,
        "run_real_rpg_turn",
        fake_run_real_rpg_turn,
    )

    result = autoplay_llm_campaign._call_turn_runtime(
        simulation_state={},
        session_id="s",
        player_action="I observe.",
        turn_index=1,
        base_url="http://testserver",
    )

    assert result["ok"] is False
    assert captured["base_url"] == "http://testserver"
    assert "NameError" not in str(result)