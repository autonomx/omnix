from argparse import Namespace
from pathlib import Path

from tests.rpg import autoplay_llm_campaign


def test_arg_parser_accepts_start_app_server_flag():
    parser = autoplay_llm_campaign.build_arg_parser()
    args = parser.parse_args(
        [
            "--turns",
            "1",
            "--player-agent",
            "fallback",
            "--start-app-server",
            "--server-startup-timeout",
            "7",
        ]
    )

    assert args.start_app_server is True
    assert args.server_startup_timeout == 7


def test_real_runtime_preflight_returns_health_after(monkeypatch):
    monkeypatch.setattr(
        autoplay_llm_campaign,
        "probe_live_http_health",
        lambda base_url: {"ok": False, "base_url": base_url, "reason": "down"},
    )
    monkeypatch.setattr(
        autoplay_llm_campaign,
        "start_managed_app_server",
        lambda **kwargs: {"ok": False, "reason": "not_started"},
    )
    monkeypatch.setattr(
        autoplay_llm_campaign,
        "describe_turn_runtime_candidates",
        lambda: [],
    )

    result = autoplay_llm_campaign._real_runtime_preflight(
        base_url="http://testserver",
        start_app_server=True,
        server_startup_timeout=1,
    )

    assert result["ok"] is False
    assert result["start_app_server_requested"] is True
    assert result["managed_server"]["reason"] == "not_started"


def test_strict_real_runtime_fails_before_turns_when_preflight_fails(monkeypatch, tmp_path: Path):
    monkeypatch.setattr(
        autoplay_llm_campaign,
        "_real_runtime_preflight",
        lambda **kwargs: {
            "ok": False,
            "base_url": kwargs["base_url"],
            "start_app_server_requested": kwargs["start_app_server"],
            "health_before": {"ok": False},
            "managed_server": {"ok": False, "reason": "not_started"},
            "health_after": {"ok": False},
            "turn_runtime_candidates": [],
        },
    )
    monkeypatch.setattr(
        autoplay_llm_campaign,
        "describe_provider_shape",
        lambda provider: {},
    )

    args = Namespace(
        turns=3,
        session_id="autoplay_test_session",
        scenario_seed="tavern_story_seed",
        player_agent="fallback",
        strategy="balanced_story_player",
        player_agent_max_tokens=200,
        suggested_action_limit=12,
        artifact_detail="full",
        output_dir=str(tmp_path),
        base_url="http://testserver",
        start_app_server=True,
        server_startup_timeout=1,
        max_repeated_actions=5,
        max_no_progress_turns=0,
        stop_on_loop=False,
        fail_on_runtime_error=True,
        fail_on_compatibility_turn_runtime=True,
        max_player_agent_fallback_rate=1.0,
        fail_on_regression_warnings=True,
        debug_provider_shape=False,
        debug_turn_runtime_shape=False,
    )

    summary = autoplay_llm_campaign.run_autoplay_campaign(args)

    assert summary["ok"] is False
    assert summary["turns_executed"] == 0
    assert summary["stopped_reason"] == "real_turn_runtime_preflight_failed"
    assert summary["start_app_server_requested"] is True
    assert "real_turn_runtime_preflight_failed" in summary["health"]["warnings"]
    assert summary["health"]["metrics"]["compatibility_turn_runtime_count"] == 0
    assert summary["health"]["metrics"]["real_turn_runtime_count"] == 0


def test_start_app_server_flag_is_forwarded_to_preflight(monkeypatch, tmp_path: Path):
    captured = {}

    def fake_preflight(**kwargs):
        captured.update(kwargs)
        return {
            "ok": False,
            "base_url": kwargs["base_url"],
            "start_app_server_requested": kwargs["start_app_server"],
            "health_before": {"ok": False},
            "managed_server": {"ok": False, "reason": "not_started"},
            "health_after": {"ok": False},
            "turn_runtime_candidates": [],
        }

    monkeypatch.setattr(autoplay_llm_campaign, "_real_runtime_preflight", fake_preflight)
    monkeypatch.setattr(autoplay_llm_campaign, "describe_provider_shape", lambda provider: {})

    args = Namespace(
        turns=1,
        session_id="autoplay_test_session",
        scenario_seed="tavern_story_seed",
        player_agent="fallback",
        strategy="balanced_story_player",
        player_agent_max_tokens=200,
        suggested_action_limit=12,
        artifact_detail="full",
        output_dir=str(tmp_path),
        base_url="http://testserver",
        start_app_server=True,
        server_startup_timeout=9,
        max_repeated_actions=5,
        max_no_progress_turns=0,
        stop_on_loop=False,
        fail_on_runtime_error=True,
        fail_on_compatibility_turn_runtime=True,
        max_player_agent_fallback_rate=1.0,
        fail_on_regression_warnings=True,
        debug_provider_shape=False,
        debug_turn_runtime_shape=False,
    )

    summary = autoplay_llm_campaign.run_autoplay_campaign(args)

    assert captured["start_app_server"] is True
    assert captured["server_startup_timeout"] == 9
    assert summary["start_app_server_requested"] is True
    assert summary["real_runtime_preflight"]["start_app_server_requested"] is True