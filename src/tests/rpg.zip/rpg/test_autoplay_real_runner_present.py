import inspect

from tests.rpg import autoplay_llm_campaign as campaign


def test_real_autoplay_runner_exists_and_is_not_placeholder():
    source = inspect.getsource(campaign)

    assert "campaign_execution:not_implemented" not in source
    assert "TODO: Implement actual turn loop here" not in source
    assert "AutoplayBackgroundPipeline" in source
    assert "for turn_index" in source or "while" in source