from tests.rpg.autoplay_llm_campaign import (
    _apply_direct_graph_display_quality_pass,
    _ensure_social_npc_line_coverage,
)


def test_social_bran_action_gets_deterministic_npc_line_when_missing():
    row = _ensure_social_npc_line_coverage(
        {
            "player_action": "I ask Bran who saw the traveler near the side door.",
            "narration": "The conversation focuses on the immediate lead.",
        }
    )

    assert row["npc_line_fallback_applied"] is True
    assert row["npc_speaker"] == "Bran"
    assert row["npc_line"]


def test_existing_npc_line_is_preserved():
    row = _ensure_social_npc_line_coverage(
        {
            "player_action": "I ask Bran about the witness.",
            "npc_line": "I saw enough to worry me.",
        }
    )

    assert row["npc_line"] == "I saw enough to worry me."
    assert not row.get("npc_line_fallback_applied")


def test_direct_graph_report_action_gets_npc_line_after_quality_pass():
    row = _apply_direct_graph_display_quality_pass(
        {
            "player_action": "I report the ambush evidence to Bran.",
            "direct_graph_action_completion": {
                "action_id": "report_findings_to_bran",
                "mechanics": ["report", "faction_consequence", "npc_reaction"],
                "changed_parts": ["report", "faction_consequence"],
            },
            "narration": "The conversation focuses on the immediate lead.",
        }
    )

    assert row["npc_line_fallback_applied"] is True
    assert row["npc_speaker"] == "Bran"
    assert row["npc_line"]
    assert "proof" in row["npc_line"].lower() or "act" in row["npc_line"].lower()


def test_direct_graph_warn_garran_action_gets_npc_line_after_quality_pass():
    row = _apply_direct_graph_display_quality_pass(
        {
            "player_action": "I warn Garran about the ambush signs on the road.",
            "direct_graph_action_completion": {
                "action_id": "warn_garran",
                "mechanics": ["faction_consequence", "npc_reaction"],
                "changed_parts": ["npc_reaction"],
            },
            "narration": "The conversation focuses on the immediate lead.",
        }
    )

    assert row["npc_line_fallback_applied"] is True
    assert row["npc_speaker"] == "Garran"
    assert row["npc_line"]
    assert "trap" in row["npc_line"].lower() or "careful" in row["npc_line"].lower()


def test_direct_graph_magistrate_social_action_gets_npc_line_after_quality_pass():
    row = _apply_direct_graph_display_quality_pass(
        {
            "player_action": "I ask the magistrate to arrest Captain Voss.",
            "direct_graph_action_completion": {
                "action_id": "ask_magistrate_to_arrest_voss",
                "mechanics": ["faction_consequence", "npc_reaction"],
                "changed_parts": ["npc_reaction"],
            },
            "narration": "The conversation focuses on the immediate lead.",
        }
    )

    assert row["npc_line_fallback_applied"] is True
    assert row["npc_speaker"] == "Magistrate"
    assert row["npc_line"]
