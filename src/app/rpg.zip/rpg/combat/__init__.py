"""Deterministic RPG combat runtime."""
