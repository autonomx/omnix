"""Custom test report generation."""
