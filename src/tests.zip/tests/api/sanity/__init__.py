"""API sanity tests."""
