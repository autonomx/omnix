"""Phase 8.2 — Encounter Regression Tests.

Ensures encounter system continues to work after changes.
Includes determinism checks for participant ordering and action sequences.
"""

from __future__ import annotations

import copy
import os

import pytest

from app.rpg.encounter import (
    EncounterResolver,
    build_encounter_from_scene,
    build_player_actions,
    ensure_encounter_state,
)


class TestEncounterStateInvariants:
    def test_ensure_never_changes_existing_keys(self):
        """Proves ensure_encounter_state does not alter existing key values."""
        original = {
            "player_state": {
                "encounter_state": {
                    "active": True,
                    "round": 99,
                    "encounter_id": "existing_id",
                }
            }
        }
        # Take deep copy BEFORE calling ensure
        before = copy.deepcopy(original)
        ensure_encounter_state(original)

        # Existing keys must remain unchanged
        enc = original["player_state"]["encounter_state"]
        assert enc["active"] is True
        assert enc["round"] == 99
        assert enc["encounter_id"] == "existing_id"

        # And the original structure (for keys that existed) must match
        for key in before["player_state"]["encounter_state"]:
            assert original["player_state"]["encounter_state"][key] == before["player_state"]["encounter_state"][key]

    def test_same_scene_produces_same_participant_order(self):
        """Determinism check: same scene in -> same participant order."""
        scene = {
            "scene_id": "s1",
            "scene_type": "combat",
            "actors": [
                {"id": "player", "name": "Player"},
                {"id": "g1", "name": "Goblin A"},
                {"id": "g2", "name": "Goblin B"},
            ],
        }
        enc_a = build_encounter_from_scene(scene, {})
        enc_b = build_encounter_from_scene(copy.deepcopy(scene), {})
        assert enc_a == enc_b

    def test_same_action_sequence_produces_same_result(self):
        """Determinism check: same action sequence -> same encounter log/result."""
        resolver = EncounterResolver()
        scene = {
            "scene_id": "s1",
            "scene_type": "combat",
            "actors": [{"id": "player"}, {"id": "e1"}],
        }
        enc_a = resolver.start(build_encounter_from_scene(scene, {}))
        enc_b = resolver.start(build_encounter_from_scene(scene, {}))
        for _ in range(3):
            enc_a = resolver.apply_player_action(enc_a, "wait")
            enc_b = resolver.apply_player_action(enc_b, "wait")
        assert enc_a == enc_b

    def test_encounter_state_bounds(self):
        actors = [{"id": f"a{i}"} for i in range(20)]
        actors.insert(0, {"id": "player"})
        scene = {"scene_id": "s1", "scene_type": "combat", "actors": actors}
        enc = build_encounter_from_scene(scene, {})
        assert len(enc["participants"]) <= 12

    def test_actions_bounds(self):
        enc = {"encounter_type": "combat"}
        actions = build_player_actions(enc)
        assert len(actions) <= 12

    def test_log_bounds_in_resolver(self):
        resolver = EncounterResolver()
        enc = {
            "active": True,
            "encounter_id": "enc:s1",
            "scene_id": "s1",
            "encounter_type": "combat",
            "round": 1,
            "turn_index": 0,
            "active_actor_id": "player",
            "participants": [
                {"actor_id": "player", "name": "Player", "side": "player", "initiative": 100, "hp": 10, "max_hp": 10, "stress": 0, "status_effects": [], "can_act": True},
                {"actor_id": "e1", "name": "E1", "side": "enemy", "initiative": 99, "hp": 10, "max_hp": 10, "stress": 0, "status_effects": [], "can_act": True},
            ],
            "log": [],
            "available_actions": [],
            "status": "active",
        }
        enc = resolver.start(enc)
        # Apply many actions
        for _ in range(110):
            enc = resolver.apply_player_action(enc, "wait")
        assert len(enc["log"]) <= 100


class TestFrontendFilesExist:
    def test_encounter_client_has_expected_exports(self):
        base_path = os.path.dirname(__file__)
        path = os.path.join(base_path, "../../static/rpg/rpgEncounterClient.js")
        assert os.path.exists(path)
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "class RPGEncounterClient" in content

    def test_encounter_renderer_has_expected_exports(self):
        base_path = os.path.dirname(__file__)
        path = os.path.join(base_path, "../../static/rpg/rpgEncounterRenderer.js")
        assert os.path.exists(path)
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "renderEncounterState" in content